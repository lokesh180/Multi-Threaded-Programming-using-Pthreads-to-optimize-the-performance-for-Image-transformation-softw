/*
Author: David Holmqvist <daae19@student.bth.se>
*/

#include "filters.hpp"
#include "matrix.hpp"
#include "ppm.hpp"
#include <cmath>

namespace Filter {

namespace Gauss {//Dont touch this function, since it will impact the results for the comparison, even if it approximate to a similar value, it will not be exactly the same.

    void get_weights(int n, double* weights_out)
    {
        for (auto i { 0 }; i <= n; i++) { //change for itteration two.
            double x { static_cast<double>(i) * max_x / n};
            weights_out[i] = exp(-x * x * pi);
        }
    }
}
struct BlurDataPasser{
int startX{0};
int stopX{0};
float sizeX{0};
float sizeY{0};
unsigned radius{0};
Matrix* m;
Matrix* writeMatrix;
};
void* calcBlurThread(void* arg){
    Matrix scratch { PPM::max_dimension };
    struct BlurDataPasser *blurDP= (struct BlurDataPasser*)arg;
    float startX = blurDP->startX;
    float stopX = blurDP->stopX;
    float sizeX = blurDP->sizeX;
    float sizeY = blurDP->sizeY;
    unsigned radius = blurDP->radius;
    Matrix* dst = blurDP->m;
    Matrix* writeMatrix = blurDP->writeMatrix;
    double w[Gauss::max_radius] {};
    Gauss::get_weights(radius, w);

     for (auto y { 0 }; y < sizeY; y++) {
        for (auto x { startX }; x < stopX; x++) {
            auto r { w[0] * dst->r(x, y) }, g { w[0] * dst->g(x, y) }, b { w[0] * dst->b(x, y) }, n { w[0] };
            for (auto wi { 1 }; wi <= radius; wi++) {
                auto wc { w[wi] };
                auto x2 { x - wi };
                if (x2 >= 0) {
                    r += wc * dst->r(x2, y);
                    g += wc * dst->g(x2, y);
                    b += wc * dst->b(x2, y);
                    n += wc;
                }
                x2 = x + wi;
                if (x2 < sizeX) {
                    r += wc * dst->r(x2, y);
                    g += wc * dst->g(x2, y);
                    b += wc * dst->b(x2, y);
                    n += wc;
                }
            }
            scratch.r(x, y) = r / n;
            scratch.g(x, y) = g / n;
            scratch.b(x, y) = b / n;
        }
    }

    for (auto y { 0 }; y < sizeY; y++) {
        //Gauss::get_weights(radius, w);
        for (auto x { startX }; x < stopX; x++) {
            auto r { w[0] * scratch.r(x, y) }, g { w[0] * scratch.g(x, y) }, b { w[0] * scratch.b(x, y) }, n { w[0] };
            for (auto wi { 1 }; wi <= radius; wi++) {
                auto wc { w[wi] };
                auto y2 { y - wi };
                if (y2 >= 0) {
                    r += wc * scratch.r(x, y2);
                    g += wc * scratch.g(x, y2);
                    b += wc * scratch.b(x, y2);
                    n += wc;
                }
                y2 = y + wi;
                if (y2 < sizeY) {
                    r += wc * scratch.r(x, y2);
                    g += wc * scratch.g(x, y2);
                    b += wc * scratch.b(x, y2);
                    n += wc;
                }
            }
            writeMatrix->r(x, y) = r / n;
            writeMatrix->g(x, y) = g / n;
            writeMatrix->b(x, y) = b / n;
        }
    }
    pthread_exit(NULL);

}
//Works as intended
void* calcBlur(unsigned stopX,unsigned stopY,unsigned radius, Matrix* dst,Matrix* writeMatrix){
    Matrix scratch { PPM::max_dimension };
    float xSize = stopX;
    float ySize = stopY;
    double w[Gauss::max_radius] {};
    Gauss::get_weights(radius, w);
     for (auto y { 0 }; y < ySize; y++) {

        for (auto x { 0 }; x < xSize; x++) {
            auto r { w[0] * dst->r(x, y) }, g { w[0] * dst->g(x, y) }, b { w[0] * dst->b(x, y) }, n { w[0] };
            for (auto wi { 1 }; wi <= radius; wi++) {
                auto wc { w[wi] };
                auto x2 { x - wi };
                if (x2 >= 0) {
                    r += wc * dst->r(x2, y);
                    g += wc * dst->g(x2, y);
                    b += wc * dst->b(x2, y);
                    n += wc;
                }
                x2 = x + wi;
                if (x2 < xSize) {
                    r += wc * dst->r(x2, y);
                    g += wc * dst->g(x2, y);
                    b += wc * dst->b(x2, y);
                    n += wc;
                }
            }
            scratch.r(x, y) = r / n;
            scratch.g(x, y) = g / n;
            scratch.b(x, y) = b / n;
        }
    }
    for (auto y { 0 }; y < ySize; y++) {
         //Gauss::get_weights(radius, w);
        for (auto x { 0 }; x < xSize; x++) {
            auto r { w[0] * scratch.r(x, y) }, g { w[0] * scratch.g(x, y) }, b { w[0] * scratch.b(x, y) }, n { w[0] };
            for (auto wi { 1 }; wi <= radius; wi++) {
                auto wc { w[wi] };
                auto y2 { y - wi };
                if (y2 >= 0) {
                    r += wc * scratch.r(x, y2);
                    g += wc * scratch.g(x, y2);
                    b += wc * scratch.b(x, y2);
                    n += wc;
                }
                y2 = y + wi;
                if (y2 < ySize) {
                    r += wc * scratch.r(x, y2);
                    g += wc * scratch.g(x, y2);
                    b += wc * scratch.b(x, y2);
                    n += wc;
                }
            }
            writeMatrix->r(x, y) = r / n;
            writeMatrix->g(x, y) = g / n;
            writeMatrix->b(x, y) = b / n;
        }
    }

return 0;
}



struct DataPasser{
int start{0};
int stop{0};
int sum{0};
Matrix* m;
};
void* calcThresholdThread(void* arg){
    unsigned psum {};
    struct DataPasser *test= (struct DataPasser*)arg;
    int start = test->start;
    int stop  = test->stop;
    int sum = test->sum;
    Matrix* m = test->m;
    //std::cout<<start<<" "<<stop<<'\n';
    for (auto i {start}; i < stop; i++) {//This part is interesting
        psum = m->r(i, 0) + m->g(i, 0) + m->b(i, 0);
        if (sum>psum) {
            m->r(i, 0) = m->g(i, 0) = m->b(i, 0) = 0;
        }
        else {
            m->r(i, 0) = m->g(i, 0) = m->b(i, 0) = 255;
        }
    }
pthread_exit(NULL);

}
void* calcThreshold(unsigned start, unsigned stop,unsigned sum, Matrix* m){
    unsigned psum {};
    //unsigned sumtemp = sum;
    //std::cout<<start<<" "<<stop<<'\n';
    for (auto i {start}; i < stop; i++) {//This part is interesting
        psum = m->r(i, 0) + m->g(i, 0) + m->b(i, 0);
        if (sum>psum) {
            m->r(i, 0) = m->g(i, 0) = m->b(i, 0) = 0;
        }
        else {
            m->r(i, 0) = m->g(i, 0) = m->b(i, 0) = 255;
        }
    }
return 0;
}
Matrix blur(Matrix m, const int radius,const int threads)
{
    auto dst { m };//input matrix.
    auto writeMatrix { m };//Read from original image, and store to the output.
    float xSize = dst.get_x_size(); //change for itteration one.
    float ySize = dst.get_y_size(); //change for itteration one.
    if(threads==1){
     calcBlur(xSize,ySize,radius,&dst,&writeMatrix);
    }
    else{
    //Matrix scratch { PPM::max_dimension };
    struct BlurDataPasser intervals[threads];

    //initialize structs and calculate offsets
    int offsetX = xSize/threads;
    for(auto i{0};i<threads;i++){
    intervals[i].startX = offsetX*i;
    intervals[i].stopX  = offsetX*i + offsetX;
    intervals[i].sizeX = xSize;
    intervals[i].sizeY = ySize;
    intervals[i].radius = radius;
    intervals[i].m = &dst;
    intervals[i].writeMatrix = &writeMatrix;
    }
    //load balansing
    unsigned diff =xSize-intervals[threads-1].stopX;
    if(diff>0){
        for(auto i{0};i<diff;i++){
            intervals[i].startX++;
            intervals[i].stopX++;
        }
        intervals[0].startX = 0;
        intervals[threads-1].stopX = xSize;
    }


     //Create workers
      pthread_t workers[threads];
      for(auto i{0}; i<threads;i++){
       pthread_create(&workers[i],nullptr,calcBlurThread,&intervals[i]);
      }
      //Wait for the workers to finnish their job.
      for(auto i{0};i<threads;i++){
        pthread_join(workers[i],nullptr);
       }
    }
return writeMatrix;
}
Matrix threshold(Matrix m, const int threads)
{
    auto dst { m };
    unsigned sum{0},nump { dst.get_x_size() * dst.get_y_size() };
    //std::cout<<"REAL NUMP "<<nump<<'\n';
    for (auto i { 0 }; i < nump; i++) {
        sum += dst.r(i, 0) + dst.g(i, 0) + dst.b(i, 0);
    }
    //If only on thread, run it sequential.
    if(threads==1){
     sum /= nump;
     calcThreshold(0,nump,sum,&dst);
    }
    else{
    //Compute ranges.
    struct DataPasser intervals[threads];
    int offset = nump/threads;
    for(auto i{0};i<threads;i++){
    intervals[i].start = offset*i;
    intervals[i].stop  = offset*i + offset;
    intervals[i].sum = sum/nump;
    intervals[i].m = &dst;
    }
    //Load balancing threads
    unsigned diff =nump-intervals[threads-1].stop;
    if(diff>0){
        for(auto i{0};i<diff;i++){
            intervals[i].start++;
            intervals[i].stop++;
        }
        intervals[0].start = 0;
        intervals[threads-1].stop = nump;
    }
    //intervals[threads-1].stop = nump;//Restore the trunkated value

      //Create workers
      pthread_t workers[threads];
      for(auto i{0}; i<threads;i++){
       pthread_create(&workers[i],nullptr,calcThresholdThread,&intervals[i]);
      }
        //Wait for the workers to finnish their job.
      for(auto i{0};i<threads;i++){
     pthread_join(workers[i],nullptr);
}
    }
    return dst;
}

}


