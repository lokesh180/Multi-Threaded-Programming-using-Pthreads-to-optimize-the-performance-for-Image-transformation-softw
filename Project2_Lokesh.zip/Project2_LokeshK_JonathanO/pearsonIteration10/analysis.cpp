/*
Author: David Holmqvist <daae19@student.bth.se>
*/

#include "analysis.hpp"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <list>
#include <vector>

namespace Analysis {

struct corrData{
unsigned start{0};
unsigned stop{0};
std::vector<double> working{};
std::vector<Vector> datasets;

};

void* seqCorrelation(std::vector<double>* results,std::vector<Vector> datasets){

    //Calculate pearson correlation coefficients
    for (auto sample1 { 0 }; sample1 < datasets.size() - 1; sample1++) {
        for (auto sample2 { sample1 + 1 }; sample2 < datasets.size(); sample2++) {
            auto corr {pearson(datasets[sample1], datasets[sample2]) };
            results->insert(results->end(),corr);

        }
    }
return 0;
}

void* threadCorrelation(void *arg){
struct corrData *corrDP= (struct corrData*)arg;

    //Calculate pearson correlation coefficients
    for (auto sample1 { corrDP->start }; sample1 < corrDP->stop; sample1++) {
        for (auto sample2 { sample1 + 1}; sample2 < corrDP->datasets.size(); sample2++) {
            auto corr {pearson(corrDP->datasets[sample1], corrDP->datasets[sample2]) };
            corrDP->working.insert(corrDP->working.end(),corr);

        }
    }

    pthread_exit(NULL);

}

std::vector<double> correlation_coefficients(std::vector<Vector> datasets, unsigned threads)
{
    //Pre allocate memory to avoid extra copying.
    unsigned factor1 = (datasets.size()-1)*((datasets.size()-1)+1)>>1;
    std::vector<double> result {};
    result.reserve(factor1);
    if(threads==1){
        seqCorrelation(&result,datasets);
    }
    else{

   //Calculate ranges
    struct corrData intervals[threads];
    int resaverad = factor1/threads;
    int range = datasets.size()/threads;
    int offset = range/threads;
     //Initalize threads.
    for(auto i{0};i<threads;i++){
        intervals[i].start = i*range-offset;
        intervals[i].stop = i*range+range-offset;
        intervals[i].datasets=datasets;
        intervals[i].working.reserve(resaverad);
    }


        //Squeeze the AOC to the left, optimizing for larger files.
      if(threads>2 && datasets.size()>=512){
       for(auto i{1};i<threads;i++){
           intervals[i].stop-=offset;
           intervals[i+1].start-=offset;
    }

      }

      //fix the outbound ranges.
      intervals[threads-1].stop = datasets.size();
      intervals[0].start = 0;


    //create workers.
    pthread_t workers[threads];
    for(auto i{0};i<threads;i++){
    pthread_create(&workers[i],nullptr,threadCorrelation,&intervals[i]);
    }

      //Wait for the workers to finnish their job.
      for(auto i{0};i<threads;i++){
        pthread_join(workers[i],nullptr);
       }
        //merge all the work from the threads.
       for(auto i{0};i<threads;i++){
        for(auto j{0};j<intervals[i].working.size();j++){
            result.insert(result.end(),intervals[i].working[j]);

        }
    }
    }

    return result;
}

double pearson(Vector vec1, Vector vec2)
{
    auto x_mean { vec1.mean() };
    auto y_mean { vec2.mean() };

    auto x_mm { vec1 - x_mean };
    auto y_mm { vec2 - y_mean };

    auto x_mag { x_mm.magnitude() };
    auto y_mag { y_mm.magnitude() };

    auto x_mm_over_x_mag { x_mm / x_mag };
    auto y_mm_over_y_mag { y_mm / y_mag };

    auto r { x_mm_over_x_mag.dot(y_mm_over_y_mag) };

    return std::max(std::min(r, 1.0), -1.0);
}
};
