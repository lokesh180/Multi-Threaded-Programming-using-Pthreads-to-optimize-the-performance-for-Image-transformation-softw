/*
Author: David Holmqvist <daae19@student.bth.se>
*/

#include "dataset.hpp"
#include "vector.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <iterator>
#include <limits>
#include <algorithm>
#include <iomanip>

namespace Dataset {
std::vector<Vector> read(std::string filename)
{
    unsigned dimension {};
    std::vector<Vector> result {};
    std::ifstream f {};

    f.open(filename);
    char buf[8192];
    f.rdbuf()->pubsetbuf(buf,sizeof(buf));
    if (!f) {
        std::cerr << "Failed to read dataset(s) from file " << filename << std::endl;
        return result;
    }

    f >> dimension;
    std::string line {};

    std::getline(f, line); // ignore first newline

    while (std::getline(f, line)) {
        std::stringstream ss { line };
        Vector new_vec { dimension };
        std::copy_n(std::istream_iterator<double> { ss },
            dimension,
            new_vec.get_data());
        //result.push_back(new_vec);
        result.insert(result.end(),new_vec);
    }

    return result;
}

void write(std::vector<double> data, std::string filename)
{
    std::ofstream f {};
    f.open(filename);
    char buf[8192];
    f.rdbuf()->pubsetbuf(buf,sizeof(buf));

    if (!f) {
        std::cerr << "Failed to write data to file " << filename << std::endl;
        return;
    }
    for (auto i { 0 }; i < data.size(); i++) {
        f << std::setprecision(std::numeric_limits<double>::digits10 + 1) << data[i] << '\n';
    }
}

};
